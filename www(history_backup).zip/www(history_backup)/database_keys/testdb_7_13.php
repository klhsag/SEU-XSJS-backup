<?php
$servername="localhost";
$db_username="root";
$db_password="123456";
$database="testdb_7_13";
?>