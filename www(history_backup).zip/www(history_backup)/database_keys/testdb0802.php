<?php
$servername="localhost";
$db_username="root";
$db_password="123456";
$database="testdb0802";
?>