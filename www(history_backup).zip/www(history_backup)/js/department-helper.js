$(document).ready(function(){
	//页面加载完执行
	onRequestGrades(false);
	document.getElementById("admin_id").innerHTML=php_department_id;
});

//页面加载前执行
var grades_data=[];



function onRequestGrades(real){
	if(real===undefined) real=true;
	var xmlhttp=new XMLHttpRequest();
	xmlhttp.open("get","depa_info_request.php",true);
	
	xmlhttp.onreadystatechange=function(){
		if(xmlhttp.readyState === 4 && xmlhttp.status === 200) {
			var resObj=JSON.parse(xmlhttp.responseText);
			if(resObj.flag=='ok'){
				grades_data=resObj['gdata'];
				stat_data=resObj['stat'];
				var table1 = produceTable('table_glob', stat_data,'院系','平均分','完成人数比例(%)');
				document.getElementById('stat_table').innerHTML = table1;
				var table2 = produceTable('tableId', grades_data,'学号','分数');
				document.getElementById('grade_table').innerHTML = table2;

				var left_data = [[]];
				var rowCnt = grades_data.length;
				var p=0;
				for (var i=0;i<rowCnt;i++){
					if (parseInt(grades_data[i][1])<parseInt(0)){
						left_data[p] = grades_data[i];
						p++;
					}
				}
				var table3 = produceTable('table_left', left_data,'学号');
				document.getElementById('shown_table').innerHTML = table3;
				if(real)
				materialAlert('提示','已从服务器获取最新数据!',function(result){
				});
				//alert(resObj.gdata);
			}else{
				materialAlert('提示',resObj.msg,function(result){
				});
			}
		}
	};
	xmlhttp.send(null);
}
function onRequestGradesByValue(){
	for(var i=0;i<grades_data.length;i++){
		for(var j=grades_data.length-1;j>i;j--){
			if(grades_data[j][1]>grades_data[j-1][1]){
				var a=grades_data[j-1][0];
				grades_data[j-1][0]=grades_data[j][0];
				grades_data[j][0]=a;
				a=grades_data[j-1][1];
				grades_data[j-1][1]=grades_data[j][1];
				grades_data[j][1]=a;
			} 
		}
	}
	var table2 = produceTable('tableId', grades_data,'学号','分数');
	document.getElementById('grade_table').innerHTML = table2;
}
function onRequestGradesBySatus(){
	for(var i=0;i<grades_data.length;i++){
		for(var j=grades_data.length-1;j>i;j--){
			if(grades_data[j][1]<grades_data[j-1][1]){
				var a=grades_data[j-1][0];
				grades_data[j-1][0]=grades_data[j][0];
				grades_data[j][0]=a;
				a=grades_data[j-1][1];
				grades_data[j-1][1]=grades_data[j][1];
				grades_data[j][1]=a;
			} 
		}
	}
	var table2 = produceTable('tableId', grades_data,'学号','分数');
	document.getElementById('grade_table').innerHTML = table2;
}

function produceTable(table_name, data){
	//备注:data必须是个二维数组
	//此函数具体用法参考被调用的地方
	var rowCnt=data.length;
	var colCnt=arguments.length -1 -1;
	var table='<table id="'+table_name+'" border="1px" style="margin: 0 auto; border-collapse:collapse; font-size:18px; text-align:center;">';
	table+='<thead><tr>';
	for(var i=0;i<colCnt;i++){
		table+='<th>';
		table+=arguments[i +1 +1];
		table+='</th>';
	}
	table+='</tr></thead><tbody>';

	for(i=0;i<rowCnt;i++){
		table+='<tr>';
		for(var j=0;j<colCnt;j++){
			table+='<td>';
			table+=data[i][j];
			table+='</td>';
		}
		table+='</tr>';
	}

	table+='</tbody></table>';
	return table;

}

function onLogoutSubmit(){
	var xmlhttp=new XMLHttpRequest();
	//约定:对于login_handler.php,get是退出,post是登录
	xmlhttp.open("get","login_handler.php",true);
	
	xmlhttp.onreadystatechange=function(){
		if(xmlhttp.readyState === 4 && xmlhttp.status === 200) {
			var resObj=JSON.parse(xmlhttp.responseText);
			materialAlert('提示',resObj.msg,function(result){
				if(resObj['flag']=='ok'){
				window.location.assign('index.php');
				}
			});
		}
	};
	xmlhttp.send(null);
}


var idTmr;
function  getExplorer() {
	var explorer = window.navigator.userAgent ;
	//ie 
	if (explorer.indexOf("MSIE") >= 0||(!!window.ActiveXObject || "ActiveXObject" in window)) {
	    return 'ie';
	}
	//firefox 
	else if (explorer.indexOf("Firefox") >= 0) {
	    return 'Firefox';
	}
	else if(explorer.indexOf("Edge") >= 0) {
		return 'Edge';
	}
	//Chrome
	else if(explorer.indexOf("Chrome") >= 0){
	    return 'Chrome';
	}
	//Opera
	else if(explorer.indexOf("Opera") >= 0){
	    return 'Opera';
	}
	//Safari
	else if(explorer.indexOf("Safari") >= 0){
	    return 'Safari';
	}

}
function ExportToExcel(tableid) {//整个表格拷贝到EXCEL中
	var signal=getExplorer();
	if(signal=='ie')
	{
	    try{       
            var curTbl = document.getElementById('tableId'); 
            var oXL = new ActiveXObject("Excel.Application"); 
            //创建AX对象excel  
            var oWB = oXL.Workbooks.Add(); 
            //获取workbook对象  
            var oSheet = oWB.ActiveSheet; 

            var lenRow = curTbl.rows.length; 
            //取得表格行数  
            for (i = 0; i < lenRow; i++) 
            { 
                var lenCol = curTbl.rows(i).cells.length; 
                //取得每行的列数  
                for (j = 0; j < lenCol; j++) 
                { 
                    oSheet.Cells(i + 1, j + 1).value = curTbl.rows(i).cells(j).innerText;  

                } 
            } 
            oXL.Visible = true; 
            //设置excel可见属性  
      }catch(e){ 
            if((!+'/v1')){ //ie浏览器  
            materialAlert('提示',"无法启动Excel，请确保电脑中已经安装了Excel!\n如果已经安装了Excel，"+"请调整IE的安全级别。\n具体操作：\n"+"工具 → Internet选项 → 安全 → 自定义级别 → ActiveX 控件和插件 → 对未标记为可安全执行脚本的ActiveX 控件初始化并执行脚本 → 启用 → 确定",function(result){
				});
           }else{ 
           	materialAlert('提示','请使用IE浏览器进行“导入到EXCEL”操作！',function(result){
				});

             //方便设置安全等级，限制为ie浏览器  
           } 
       } 
	}
	else{
		var curTbl = document.getElementById('tableId').outerHTML; 
	    var excelHtml = "<html><head><meta charset='utf-8' /><style>td{border:1px #000 solid;border-collapse:collapse;} </style></head><body>"+curTbl+"</body></html>";
	    var excelBlob = new Blob([excelHtml], {type: 'application/vnd.ms-excel'})
	    // 创建一个a标签
	    var oA = document.createElement('a');
	    // 利用URL.createObjectURL()方法为a元素生成blob URL
	    oA.href = URL.createObjectURL(excelBlob);
	    // 给文件命名
	    oA.download = '本院系2018校史校情知识竞赛学生成绩.xls';
	    // 模拟点击
	    oA.click();
	    // 移除
	    oA.remove();

	}

	}