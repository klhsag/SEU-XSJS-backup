$(document).ready(function(){
	//页面加载完执行
	//showRegisterAns();
});
/*
//w3c官网的cookie代码
//设置cookie
function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires="+d.toUTCString();
    document.cookie = cname + "=" + cvalue + "; " + expires + ";  path=/";   //切记设置好路径
}
//获取cookie
function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i=0; i<ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1);
        if (c.indexOf(name) != -1) return c.substring(name.length, c.length);
    }
    return "";
}
//清除cookie  
function clearCookie(name) {  
    setCookie(name, "", -1);  
}
*/

function showRegisterAns(got_res_echo){
		document.getElementById('register').style.display = "none";
		document.getElementById('register_ans').style.display = "";
		
		//由于cookie能够传递的信息有限, 所以在本地加工处理
		document.getElementById('register_back_btn').setAttribute("onclick","changeDiv();");
		if (got_res_echo=="exist"){
			got_res_echo="<p>该一卡通号已存在！请检查您的输入</p>";
		}else if (got_res_echo=="user_error"){
			got_res_echo="<p>一卡通号错误，请检查您输入的信息是否正确</p>";
		}else if (got_res_echo=="pwd_error"){
			got_res_echo="<p>学号错误，不能与一卡通号匹配，请检查您的输入</p>";
		}else { //检测成功
			got_res_echo = "<p>信息录入成功，请检查您的信息。</p><p>其中一卡通号为您的用户名，学号为您的密码。</p>"+got_res_echo;
			document.getElementById('register_back_btn').setAttribute("onclick","window.location.assign('/index.php');");
		}

		document.getElementById('register_info').innerHTML = got_res_echo+"<p><em>如有疑问，请点击注册界面的申诉按钮</em></p>";
}

function showWnd(wndName) {
	document.getElementById('register').style.display = "none";
	document.getElementById('register_ans').style.display = "none";
	document.getElementById(wndName).style.display = "";
}

function changeDiv() {
	if (document.getElementById('register').style.display == "none"){
		showWnd('register');
	}else{
		showWnd('register_ans');
	}
}