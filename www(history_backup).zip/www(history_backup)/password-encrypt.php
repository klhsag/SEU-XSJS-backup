<?php

function password_encrypt($pwd){
    return $pwd;                     //因为是学号作密码所以干脆明文吧
}

?>