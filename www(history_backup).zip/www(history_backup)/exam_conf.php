<?php
$conf_choice_all=5; //选择题在数据库中的总数,需要和数据库一致
$conf_judge_all=4;  //判断题在数据库中的总数,需要和数据库一致
$conf_choice_cnt=2;
$conf_judge_cnt=1;
$conf_choice_score=12;
$conf_judge_score=10;
$second_required_between_requests=1;  //刷卷最低间隔
$second_required_before_submit=1;
$conf_time_limit=3000+60;             //60s是考虑网络延迟等原因的固定加时
$debug_mode=true;   //开启debug_mode后可以反复做题,否则服务器会拒绝考试请求。 //此功能已废弃
?>
