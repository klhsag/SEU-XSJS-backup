<?php

require "view/register.html";

//echo "<script></script>";


if (!isset( $_POST["new_username"] ) ) {
	//echo "<script> alert('没有表单'); </script>";
	echo "<script> showWnd('register'); </script>";
}else{
	//echo "<script> alert('有表单'); </script>";
	require 'database_keys/testdb0802.php';
	//
	$echo_str = "";
    try {
        $conn = new PDO("mysql:host=$servername; dbname=$database", $db_username, $db_password);
        
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        
        $stmt = $conn->prepare("SELECT username,password FROM member WHERE username=:username OR password=:pwd");
        $username = trim($_POST["new_username"]);
        $pwd = trim($_POST["new_password"]);
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':pwd', $pwd);
        $stmt->execute();
        
        $rows=$stmt->fetchAll();
        $rowCount=$stmt->rowCount();
        if($rowCount>=1) {
            $echo_str = "exist";
            //$tmp1 = $rows[0]['username'];
            //$tmp2 = $rows[0]['password'];
        }else{
            $content = file_get_contents("http://xk.urp.seu.edu.cn/jw_service/service/stuCurriculum.action?queryStudentId=".$username."&queryAcademicYear=18-19-1");
            //echo "$content";
            $pattern = "/学号:.{8}/";
            preg_match($pattern, $content, $matches);

            $pat_pwd = "学号:".$pwd;                              //反过来进行完全匹配(正向不容易处理部分匹配问题)

            if (sizeof($matches)==0){                         //一卡通输入错误
                $echo_str = $echo_str."user_error";
            }else if(preg_match("/".$matches[0]."/", $pat_pwd)==0){
                //$echo_str = $echo_str."<p>一卡通与学号信息不匹配！</p>";
                $echo_str = "pwd_error";
            }else{
                $echo_str = $echo_str."<p>一卡通号:$username</p>";
                $echo_str = $echo_str."<p>$pat_pwd</p>";
                $d_id = "$pwd[0]"."$pwd[1]";
                var_dump($d_id);
                $stmt = $conn->prepare("INSERT INTO member(username, password, department_id)
                                        VALUES (:username, :pwd, :d_id)");
                $stmt->bindParam(':username', $username);
                $stmt->bindParam(':pwd', $pwd);
                $stmt->bindParam(':d_id', $d_id);
                $stmt->execute();
            }
        }

        $conn = null;
    }
    catch(PDOException $ex){
    	//先不搞这些玩意
    }

    /*
    $url = "/view/register.html";  
    echo "<script type='text/javascript'>";
    echo "document.cookie='res_msg=$echo_str; path=/'; ";
    echo "window.location.assign('$url');";
    echo "</script>";
	*/

    echo "<script> showRegisterAns('$echo_str'); </script>";  //虽然机理很奇怪，总之这个字符串请加上引号来作为参数
}


?>